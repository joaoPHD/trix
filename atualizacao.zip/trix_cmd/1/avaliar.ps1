chcp 65001
cls
$winsat = Get-CimInstance Win32_WinSAT

Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "         RESULTADO DO DESEMPENHO" -ForegroundColor Cyan
Write-Host "=====================================`n" -ForegroundColor Cyan

Write-Host "Processador (CPU):           " $winsat.CPUScore
Write-Host "Memoria RAM:                 " $winsat.MemoryScore
Write-Host "Graficos (Tela):             " $winsat.GraphicsScore
Write-Host "Graficos 3D:                 " $winsat.D3DScore
Write-Host "Disco (HD/SSD):              " $winsat.DiskScore
Write-Host "Nota Geral:                  " $winsat.WinSPRLevel

Write-Host "`n====================================="
Start-Sleep -Seconds 2

write-host "esperando confimacao..."
write-host "presione qualquer tecla para confirmar"
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

cmd /c "C:\trix_cmd\1\verifica.bat"
exit

